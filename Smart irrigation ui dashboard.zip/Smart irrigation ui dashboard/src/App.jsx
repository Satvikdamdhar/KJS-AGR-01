import React, { useState } from 'react';
import './App.css';

const SIDEBAR_ITEMS = [
  { icon: '📊', label: 'Dashboard', active: true },
  { icon: '🚜', label: 'My Farms' },
  { icon: '📡', label: 'Sensors' },
  { icon: '🌤', label: 'Weather' },
  { icon: '🚰', label: 'Pump Control' },
  { icon: '🏛', label: 'Government Schemes' },
  { icon: '🌾', label: 'Crop Advisory' },
  { icon: '📄', label: 'Reports' },
  { icon: '⚙️', label: 'Settings' },
  { icon: '❓', label: 'Help' },
];

const OVERVIEW_CARDS = [
  {
    icon: '🌱',
    title: 'Soil Moisture',
    value: '42%',
    status: 'LOW',
    tone: 'warning',
  },
  {
    icon: '💧',
    title: 'Water Tank',
    value: '78%',
    status: 'Normal',
    tone: 'safe',
  },
  {
    icon: '🌤',
    title: 'Weather',
    value: '30°C',
    extra: ['Humidity 70%', 'Rain 20%'],
    tone: 'info',
  },
  {
    icon: '🚰',
    title: 'Pump',
    value: 'OFF',
    status: 'Current Status',
    button: 'Start Pump',
    tone: 'critical',
  },
];

const FARMS = [
  { name: 'Field 1', crop: 'Sugarcane', area: '6 Acres', stage: 'Vegetative Stage' },
  { name: 'Field 2', crop: 'Cotton', area: '3 Acres', stage: 'Flowering Stage' },
  { name: 'Field 3', crop: 'Wheat', area: '4 Acres', stage: 'Ripening Stage' },
];

const SENSORS = [
  { icon: '💧', label: 'Soil Moisture', value: '42%', time: '2 min ago', tone: 'warning', trend: [40, 38, 42, 41, 43, 42] },
  { icon: '🌡', label: 'Temperature', value: '30°C', time: '1 min ago', tone: 'info', trend: [28, 29, 30, 29, 31, 30] },
  { icon: '💦', label: 'Humidity', value: '70%', time: '1 min ago', tone: 'safe', trend: [66, 68, 71, 69, 70, 70] },
  { icon: '🧪', label: 'pH', value: '6.8', time: '5 min ago', tone: 'safe', trend: [6.5, 6.7, 6.6, 6.8, 6.7, 6.8] },
  { icon: '🛢', label: 'Water Level', value: '78%', time: '3 min ago', tone: 'info', trend: [80, 79, 78, 78, 77, 78] },
  { icon: '🔋', label: 'Battery Status', value: '86%', time: '10 min ago', tone: 'safe', trend: [90, 88, 87, 87, 86, 86] },
];

const FORECAST = [
  { day: 'Mon', icon: '☀️', temp: '31°C', rain: '10%', wind: '12 km/h', humidity: '60%' },
  { day: 'Tue', icon: '🌤', temp: '30°C', rain: '20%', wind: '15 km/h', humidity: '70%' },
  { day: 'Wed', icon: '🌧', temp: '27°C', rain: '60%', wind: '20 km/h', humidity: '85%' },
  { day: 'Thu', icon: '🌦', temp: '28°C', rain: '40%', wind: '18 km/h', humidity: '78%' },
  { day: 'Fri', icon: '☀️', temp: '32°C', rain: '05%', wind: '10 km/h', humidity: '55%' },
  { day: 'Sat', icon: '☀️', temp: '33°C', rain: '05%', wind: '9 km/h', humidity: '52%' },
  { day: 'Sun', icon: '🌤', temp: '31°C', rain: '15%', wind: '13 km/h', humidity: '62%' },
];

const SERVICES = [
  { icon: '👨‍🌾', name: 'PM-KISAN' },
  { icon: '🛡️', name: 'Crop Insurance' },
  { icon: '💧', name: 'PMKSY Micro Irrigation' },
  { icon: '🎓', name: 'KVK' },
  { icon: '🔬', name: 'ICAR' },
  { icon: '🌾', name: 'Agriculture Advisory' },
  { icon: '📇', name: 'Directory Services' },
  { icon: '🏛', name: 'Government Schemes' },
];

const ALERTS = [
  { tone: 'critical', text: 'Soil moisture critically low.' },
  { tone: 'warning', text: 'Rain expected tomorrow.' },
  { tone: 'safe', text: 'Pump completed irrigation successfully.' },
];

const QUICK_ACTIONS = [
  { icon: '▶️', label: 'Start Pump' },
  { icon: '⏹', label: 'Stop Pump' },
  { icon: '🗓', label: 'Schedule Irrigation' },
  { icon: '📥', label: 'Download Report' },
  { icon: '👨‍🌾', label: 'Contact Agriculture Officer' },
];

function TrendBar({ data }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  return (
    <div className="trend-bars" aria-hidden="true">
      {data.map((v, i) => {
        const range = max - min || 1;
        const h = 20 + ((v - min) / range) * 80;
        return <span key={i} className="trend-bar" style={{ height: `${h}%` }}></span>;
      })}
    </div>
  );
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="dashboard">
      {/* ===== 1. Top Header ===== */}
      <header className="topbar">
        <div className="topbar-left">
          <button
            className="sidebar-toggle"
            aria-label="Toggle sidebar"
            aria-expanded={sidebarOpen}
            onClick={() => setSidebarOpen((prev) => !prev)}
          >
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
          </button>
          <span className="gov-logo" aria-hidden="true">🇮🇳</span>
        </div>

        <div className="topbar-center">
          <h1>AI Smart Irrigation Advisory System</h1>
          <p>Smart Farming • Smart Irrigation</p>
        </div>

        <div className="topbar-right">
          <button className="icon-btn" aria-label="Notifications">🔔</button>
          <button className="profile-btn" aria-label="Farmer profile">
            <span className="profile-avatar">👨‍🌾</span>
            <span className="profile-name">Ramesh Kumar</span>
          </button>
          <select className="lang-select" aria-label="Select language" defaultValue="en">
            <option value="en">English</option>
            <option value="hi">हिन्दी</option>
            <option value="pa">ਪੰਜਾਬੀ</option>
            <option value="te">తెలుగు</option>
          </select>
        </div>
      </header>

      <div className="layout">
        {/* ===== 2. Left Sidebar ===== */}
        <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          <nav aria-label="Sidebar navigation">
            <ul>
              {SIDEBAR_ITEMS.map((item) => (
                <li key={item.label}>
                  <a
                    href="#"
                    className={item.active ? 'active' : ''}
                    onClick={(e) => e.preventDefault()}
                  >
                    <span className="nav-icon" aria-hidden="true">{item.icon}</span>
                    <span className="nav-label">{item.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {sidebarOpen && (
          <div className="overlay" onClick={() => setSidebarOpen(false)}></div>
        )}

        {/* ===== Main Content ===== */}
        <main className="main">
          {/* ===== 3. Overview Cards ===== */}
          <section className="overview-section">
            <div className="overview-grid">
              {OVERVIEW_CARDS.map((card) => (
                <article className={`overview-card tone-${card.tone}`} key={card.title}>
                  <div className="overview-top">
                    <span className="overview-icon" aria-hidden="true">{card.icon}</span>
                    <span className="overview-title">{card.title}</span>
                  </div>
                  <div className="overview-value">{card.value}</div>
                  {card.status && <span className="overview-status">{card.status}</span>}
                  {card.extra &&
                    card.extra.map((line) => (
                      <span className="overview-extra" key={line}>{line}</span>
                    ))}
                  {card.button && (
                    <button className="btn btn-primary btn-sm">{card.button}</button>
                  )}
                </article>
              ))}
            </div>
          </section>

          {/* ===== 4. AI Recommendation ===== */}
          <section className="ai-recommend">
            <div className="ai-icon" aria-hidden="true">🤖</div>
            <div className="ai-content">
              <h2>AI Recommendation</h2>
              <p>
                AI recommends irrigation within the next 3 hours because soil moisture is
                below the recommended level.
              </p>
              <div className="ai-buttons">
                <button className="btn btn-primary">Start Irrigation</button>
                <button className="btn btn-outline">View Details</button>
              </div>
            </div>
          </section>

          {/* ===== 5. Farm Overview ===== */}
          <section className="section-block">
            <h2 className="section-title">Farm Overview</h2>
            <div className="farm-grid">
              {FARMS.map((farm) => (
                <article className="farm-card" key={farm.name}>
                  <h3>{farm.name}</h3>
                  <div className="farm-row">
                    <span className="farm-label">Crop</span>
                    <strong>{farm.crop}</strong>
                  </div>
                  <div className="farm-row">
                    <span className="farm-label">Area</span>
                    <strong>{farm.area}</strong>
                  </div>
                  <div className="farm-row">
                    <span className="farm-label">Stage</span>
                    <strong>{farm.stage}</strong>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* ===== 6. Live Sensors ===== */}
          <section className="section-block">
            <h2 className="section-title">Live Sensors</h2>
            <div className="sensor-grid">
              {SENSORS.map((s) => (
                <article className={`sensor-card tone-${s.tone}`} key={s.label}>
                  <div className="sensor-head">
                    <span className="sensor-icon" aria-hidden="true">{s.icon}</span>
                    <span className="sensor-label">{s.label}</span>
                  </div>
                  <div className="sensor-value">{s.value}</div>
                  <TrendBar data={s.trend} />
                  <span className="sensor-time">Updated {s.time}</span>
                </article>
              ))}
            </div>
          </section>

          {/* ===== 7. Weather Forecast ===== */}
          <section className="section-block">
            <h2 className="section-title">7-Day Weather Forecast</h2>
            <div className="forecast-grid">
              {FORECAST.map((d) => (
                <article className="forecast-card" key={d.day}>
                  <span className="forecast-day">{d.day}</span>
                  <span className="forecast-icon" aria-hidden="true">{d.icon}</span>
                  <strong className="forecast-temp">{d.temp}</strong>
                  <span className="forecast-row">🌧 {d.rain}</span>
                  <span className="forecast-row">💨 {d.wind}</span>
                  <span className="forecast-row">💦 {d.humidity}</span>
                </article>
              ))}
            </div>
          </section>

          {/* ===== 8. Government Services ===== */}
          <section className="section-block">
            <h2 className="section-title">Government Services</h2>
            <div className="service-grid">
              {SERVICES.map((s) => (
                <a href="#" className="service-item" key={s.name} onClick={(e) => e.preventDefault()}>
                  <span className="service-icon" aria-hidden="true">{s.icon}</span>
                  <span className="service-name">{s.name}</span>
                </a>
              ))}
            </div>
          </section>

          {/* ===== 9. Alerts Panel ===== */}
          <section className="section-block">
            <h2 className="section-title">Recent Alerts</h2>
            <div className="alerts-panel">
              {ALERTS.map((a, i) => (
                <div className={`alert-row tone-${a.tone}`} key={i}>
                  <span className="alert-dot" aria-hidden="true"></span>
                  <span className="alert-text">{a.text}</span>
                </div>
              ))}
            </div>
          </section>

          {/* ===== 10. Water Usage Analytics ===== */}
          <section className="section-block">
            <h2 className="section-title">Water Usage Analytics</h2>
            <div className="analytics-grid">
              <article className="analytics-card">
                <h3>Daily Water Usage</h3>
                <div className="analytics-bars">
                  <span className="a-bar" style={{ height: '50%' }}></span>
                  <span className="a-bar" style={{ height: '70%' }}></span>
                  <span className="a-bar" style={{ height: '40%' }}></span>
                  <span className="a-bar" style={{ height: '85%' }}></span>
                  <span className="a-bar" style={{ height: '60%' }}></span>
                  <span className="a-bar" style={{ height: '45%' }}></span>
                  <span className="a-bar" style={{ height: '30%' }}></span>
                </div>
                <span className="analytics-meta">1,240 L today</span>
              </article>
              <article className="analytics-card">
                <h3>Weekly Irrigation</h3>
                <div className="analytics-ring">
                  <span className="ring-value">5</span>
                  <span className="ring-label">Sessions</span>
                </div>
                <span className="analytics-meta">8,400 L this week</span>
              </article>
              <article className="analytics-card">
                <h3>Monthly Water Savings</h3>
                <div className="savings-value">32%</div>
                <span className="analytics-meta">vs. last month</span>
              </article>
            </div>
          </section>

          {/* ===== 11. Quick Actions ===== */}
          <section className="section-block">
            <h2 className="section-title">Quick Actions</h2>
            <div className="quick-grid">
              {QUICK_ACTIONS.map((a) => (
                <button className="quick-action" key={a.label}>
                  <span className="qa-icon" aria-hidden="true">{a.icon}</span>
                  <span className="qa-label">{a.label}</span>
                </button>
              ))}
            </div>
          </section>

          {/* ===== 12. Footer ===== */}
          <footer className="footer">
            <div className="footer-top">
              <div className="footer-brand">
                <span className="gov-logo" aria-hidden="true">🇮🇳</span>
                <span>AI Smart Irrigation Advisory System</span>
              </div>
              <div className="footer-links">
                <a href="#">Contact</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Support</a>
              </div>
              <span className="nic-logo" aria-hidden="true">NIC</span>
            </div>
            <div className="footer-bottom">
              <p>© {new Date().getFullYear()} National Informatics Centre. Designed for Smart Farming.</p>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}
